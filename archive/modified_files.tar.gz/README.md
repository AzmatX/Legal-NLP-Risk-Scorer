# AI-Powered Contract Intelligence & Risk Scoring System

Production-ready starter repository for an enterprise NLP platform that ingests legal contracts, extracts intelligence, and serves risk analysis through APIs.

## Core Capabilities

- Upload PDF/DOCX contracts
- OCR extraction pipeline with Tesseract/pdf2image
- Legal entity extraction using spaCy NER
- Clause classification with transformer models
- Risk scoring engine
- Semantic search with vector embeddings
- FastAPI REST APIs
- Celery distributed task worker

## Tech Stack

- Python 3.11+
- FastAPI + Uvicorn
- Celery + Redis
- PyTorch / Transformers / spaCy
- LangChain for RAG pipelines
- Tesseract OCR + pdf2image
- Docker + Docker Compose

## Quickstart

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .[dev]
pytest -q
ruff check .
uvicorn api.main:app --app-dir src --host 0.0.0.0 --port 8000
```

## Docker

```bash
docker compose up --build
```

## Project Status

| Module | Status | Description |
|--------|--------|-------------|
| Dataset Ingestion | ✅ Complete | CUAD dataset loading, format conversion, tokenization, train/val/test splits |
| OCR Pipeline | ✅ Complete | PDF/image text extraction with Tesseract, confidence scoring, batch processing |
| NER Engine | ✅ Complete | spaCy-based entity extraction for 18 legal entity types |
| Clause Classifier | 🚧 In Progress | Transformer-based clause classification (RoBERTa-legal) |
| Risk Scoring | 📋 Planned | Clause-level and document-level risk assessment |
| API Layer | 🚧 In Progress | REST endpoints for all core services |

## Repository Maintenance

This repository follows a collaborative development model. All contributors are acknowledged in the commit history. For contribution guidelines, see `CONTRIBUTING.md`.

### Recent Development Milestones

- **Week 1**: Dataset ingestion pipeline, OCR enhancement, NER processor implementation
- **Week 2**: Clause classifier fine-tuning, evaluation metrics, post-processing heuristics

## Branch Strategy

- `main` — Production releases
- `develop` — Integration branch for features
- `feature/*` — Feature branches for active development

See `DEVELOPMENT_GUIDE.md` for detailed branching workflow.

## Documentation

- [Development Guide](DEVELOPMENT_GUIDE.md) — Build, test, and deployment procedures
- [Contributing Guidelines](CONTRIBUTING.md) — How to contribute to this project
- [Code of Conduct](CODE_OF_CONDUCT.md) — Community standards
- [Project Setup](PROJECT_SETUP.md) — Environment configuration
- [Branching Strategy](BRANCHING_STRATEGY.md) — Git workflow

## License

Proprietary — All rights reserved.
